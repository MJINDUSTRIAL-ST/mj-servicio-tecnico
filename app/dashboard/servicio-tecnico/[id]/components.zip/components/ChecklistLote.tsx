"use client";

import { useState } from "react";
import ChecklistInteligente from "./ChecklistInteligente";

type Equipo = {
  id: string;
  codigo?: string | null;
  equipo?: string | null;
  marca?: string | null;
  modelo?: string | null;
  numero_serie?: string | null;
};

type Props = {
  equipos: Equipo[];
};

export default function ChecklistLote({ equipos }: Props) {
  const [equipoAbierto, setEquipoAbierto] = useState<string | null>(
    equipos.length > 0 ? equipos[0].id : null
  );

  if (!equipos.length) {
    return (
      <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6 text-center text-amber-800">
        Esta OT aún no tiene equipos asociados.
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {equipos.map((equipo, index) => {
        const abierto = equipoAbierto === equipo.id;

        return (
          <div
            key={equipo.id}
            className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm"
          >
            <button
              type="button"
              onClick={() =>
                setEquipoAbierto(abierto ? null : equipo.id)
              }
              className="flex w-full items-center justify-between px-6 py-5 hover:bg-slate-50"
            >
              <div className="text-left">
                <h2 className="text-lg font-bold text-slate-900">
                  Equipo {index + 1}
                  {equipo.codigo ? ` · ${equipo.codigo}` : ""}
                </h2>

                <p className="mt-1 text-sm text-slate-500">
                  {equipo.equipo || "Sin tipo"}
                  {equipo.marca ? ` · ${equipo.marca}` : ""}
                  {equipo.modelo ? ` · ${equipo.modelo}` : ""}
                  {equipo.numero_serie
                    ? ` · Serie ${equipo.numero_serie}`
                    : ""}
                </p>
              </div>

              <div className="flex items-center gap-4">
                <span className="rounded-full bg-yellow-100 px-3 py-1 text-xs font-bold text-yellow-800">
                  Pendiente
                </span>

                <span className="text-2xl font-bold text-slate-400">
                  {abierto ? "−" : "+"}
                </span>
              </div>
            </button>

            {abierto && (
              <div className="border-t border-slate-200 p-6">
                <ChecklistInteligente
                  equipoId={equipo.id}
                  tipoEquipoInicial={equipo.equipo ?? ""}
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}